<?php
 
class Registration extends CI_Controller {
 
    function  __construct()  {
        parent::__construct();
         $this->load->library('session');
         $this->load->helper('url');
         $this->load->database();
    }
        //Loads the registration form if the user isnt logged in - redirects to root folder elseif. 
    public function index() 
    {
      $data['message']="";
           //Checks to see if the user is logged in
        if ($this->session->userdata('logged_in') == false)
        {
            $this->load->library('recaptcha');
        $recaptcha = $this->input->post('g-recaptcha-response');
        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $phone = $this->input->post('phone');
        $username = $this->input->post('username');
        $password = md5($this->input->post('password'));
        
             if (!empty($recaptcha)) 
             {
                $response = $this->recaptcha->verifyResponse($recaptcha);
                if (isset($response['success']) && $response['success'] === true && $fname!='' && $lname!='' && $phone!='' && $username!='' && $password!='') 
                {
                      //Register User
                  $data_ins = array(
                      'fname' => $fname ,
                      'lname' => $lname ,
                      'phone' => $phone,
                      'username' => $username,
                      'password' => $password
                  );
                  
                  $status = $this->db->insert('user', $data_ins);
                  if($status==1)
                  {
                    $msg=array('message'=>'Inserted Successfully');
                    $this->session->set_userdata($msg);
                  }
                }
            }
 
            $data = array(
                'widget' => $this->recaptcha->getWidget(),
                'script' => $this->recaptcha->getScriptTag(),
            );
                  $this->load->view('registration',$data); 
         }
     }
}
