<html>
<head>
   <title>Registration Form</title>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/style.css'; ?>">
    <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js';?>" ></script>
   <script type="text/javascript" src="<?php echo base_url().'assets/js/recaptcha.js';?>" ></script>
</head>
 
<body>
  <!-- main -->
  <div class="main">
    <h1>Registration Form</h1>
    <div class="msg">
    <span style="margin: 0px 0px 0px 148px;"><?php
    $data = $this->session->all_userdata();
    if(isset($data['message']) && !empty($data['message']))
    {
      echo $data['message'];
    }
    ?></span></div>
    <div class="signin-form">
      <form action="" method="post">
        <span style="color:red;margin:0px 0px 10px 70px">All fields are required</span>
        <ul>
          <li>
            <input type="text" placeholder="First Name" name="fname" maxlength="10" id="fname">
            
          </li>
          <li>
            <input type="text" placeholder="Last Name" name="lname" maxlength="10" id="lname">
            
          </li>
          <li>
            <input type="text" placeholder="Phone" name="phone" maxlength="10" id="phone">
            
          </li>
          <li>
            <input type="text" placeholder="User Name" name="username" maxlength="5" id="username">
            
          </li>
          <li>
            <input type="password" placeholder="Password" name="password" maxlength="8" id="password">
            
          </li>
          <li>
              <?php echo $widget;?>
              <?php echo $script;?>
          </li>
          <li>
            <input  type="submit" value="Login" id='wlisubmit' onclick="return checkval();" />
          </li>
          
        </ul>   
      </form>
    </div>  
  </div>
</body>
</html>